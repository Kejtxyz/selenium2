import org.junit.jupiter.api.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class test {
    @Test
    public void demoTest(){
        System.setProperties("webdriver.chrome.driver", "src//main//resources//chromedriver.exe");
        WebDriver driver = new ChromeDriver();

    }
}
// https://www.youtube.com/watch?v=inb1BhdH_0c&list=PLZTxwbvLNhALIupUiUw5TfROPhmPXJbmP&index=2